/**
 * [Discuz!] (C)2001-2099 Discuz! Team
 * This is NOT a freeware, use is subject to license terms
 * https://license.discuz.vip
 */

function seditor_showimgmenu(seditorkey) {
	var imgurl = $(seditorkey + '_image_param_1').value;
	var width = parseInt($(seditorkey + '_image_param_2').value);
	var height = parseInt($(seditorkey + '_image_param_3').value);
	var extparams = '';
	if(width || height) {
		extparams = '=' + width + ',' + height
	}
	seditor_insertunit(seditorkey, '[img' + extparams + ']' + imgurl, '[/img]', null, 1);
	$(seditorkey + '_image_param_1').value = '';
	hideMenu();
}

function seditor_menu(seditorkey, tag) {
	var sel = false;
	if(!isUndefined($(seditorkey + 'message').selectionStart)) {
		sel = $(seditorkey + 'message').selectionEnd - $(seditorkey + 'message').selectionStart;
	} else if(document.selection && document.selection.createRange) {
		$(seditorkey + 'message').focus();
		var sel = document.selection.createRange();
		$(seditorkey + 'message').sel = sel;
		sel = sel.text ? true : false;
	}
	if(sel) {
		seditor_insertunit(seditorkey, '[' + tag + ']', '[/' + tag + ']');
		return;
	}
	var ctrlid = seditorkey + tag;
	var menuid = ctrlid + '_menu';
	if(!$(menuid)) {
		switch(tag) {
			case 'at':
				curatli = 0;
				atsubmitid = ctrlid + '_submit';
				setTimeout(function() {atFilter('', 'at_list','atListSet');$('atkeyword').focus();}, 100);
				str = $L('input_username') + ':<br /><input type="text" id="atkeyword" style="width:240px" value="" class="px" onkeydown="atFilter(this.value, \'at_list\',\'atListSet\',event);" /><div class="p_pop" id="at_list" style="width:250px;"><ul><li>' + $L('at_notice') + '</li></ul></div>';
				submitstr = 'seditor_insertunit(\'' + seditorkey + '\', \'@\' + $(\'atkeyword\').value.replace(/<\\/?b>/g, \'\')+\' \'); hideMenu();';
				break;
			case 'url':
				str = $L('input_link_href') + ':<br /><input type="text" id="' + ctrlid + '_param_1" sautocomplete="off" style="width: 98%" value="" class="px" />' +
					'<br />' + $L('input_link_text') + ':<br /><input type="text" id="' + ctrlid + '_param_2" style="width: 98%" value="" class="px" />';
				submitstr = '$(\'' + ctrlid + '_param_2\').value !== "" ? seditor_insertunit(\'' + seditorkey + '\', \'[url=\' + seditor_squarestrip($(\'' + ctrlid + '_param_1\')).value + \']\' + $(\'' + ctrlid + '_param_2\').value, \'[/url]\', null, 1) : seditor_insertunit(\'' + seditorkey + '\', \'[url]\' + $(\'' + ctrlid + '_param_1\').value, \'[/url]\', null, 1);hideMenu();';
				break;
			case 'code':
				str = $L('input_code') + ':<br /><select id="' + ctrlid + '_param_2" class="ps">' +
					'<option value="">无</option>' +
					'<option value="bash">Bash</option>' +
					'<option value="c">C</option>' +
					'<option value="cpp">C++</option>' +
					'<option value="csharp">C#</option>' +
					'<option value="css">CSS</option>' +
					'<option value="html">HTML</option>' +
					'<option value="java">Java</option>' +
					'<option value="javascript">JavaScript</option>' +
					'<option value="json">JSON</option>' +
					'<option value="php">PHP</option>' +
					'<option value="python">Python</option>' +
					'<option value="ruby">Ruby</option>' +
					'<option value="sql">SQL</option>' +
					'<option value="xml">XML</option>' +
				'</select><br /><textarea id="' + ctrlid + '_param_1" style="width: 98%" cols="50" rows="5" class="txtarea"></textarea>';
				submitstr = 'var codeType = $(\'' + ctrlid + '_param_2\').value; var codeText = $(\'' + ctrlid + '_param_1\').value; seditor_insertunit(\'' + seditorkey + '\', \'[code\' + (codeType ? \'=\' + codeType : \'\') + \']\' + codeText, \'[/code]\', null, 1);hideMenu();';
				break;
			case 'quote':
				str = $L('input_quote') + ':<br /><textarea id="' + ctrlid + '_param_1" style="width: 98%" cols="50" rows="5" class="txtarea"></textarea>';
				submitstr = 'seditor_insertunit(\'' + seditorkey + '\', \'[quote]\' + $(\'' + ctrlid + '_param_1\').value, \'[/quote]\', null, 1);hideMenu();';
				break;
			case 'img':
				str = $L('input_img') + ':<br /><input type="text" id="' + ctrlid + '_param_1" style="width: 98%" value="" class="px" onchange="loadimgsize(this.value, \'' + seditorkey + '\',\'' + tag + '\')" />' +
					'<p class="mtm">' + $L('width') + '(' + $L('optional') + '): <input type="text" id="' + ctrlid + '_param_2" style="width: 15%" value="" class="px" /> &nbsp;' +
                    $L('height') + '(' + $L('optional') + '): <input type="text" id="' + ctrlid + '_param_3" style="width: 15%" value="" class="px" /></p>';
				submitstr = 'seditor_insertunit(\'' + seditorkey + '\', \'[img\' + ($(\'' + ctrlid + '_param_2\').value !== "" && $(\'' + ctrlid + '_param_3\').value !== "" ? \'=\' + $(\'' + ctrlid + '_param_2\').value + \',\' + $(\'' + ctrlid + '_param_3\').value : \'\') + \']\' + seditor_squarestrip($(\'' + ctrlid + '_param_1\')).value, \'[/img]\', null, 1);hideMenu();';
				break;
		}
		var menu = document.createElement('div');
		menu.id = menuid;
		menu.style.display = 'none';
		menu.className = 'p_pof upf';
		menu.style.width = '270px';
		$('append_parent').appendChild(menu);
		menu.innerHTML = '<span class="y"><a onclick="hideMenu()" class="flbc" href="javascript:;">' + $L('close') + '</a></span><div class="p_opt cl"><form onsubmit="try{' + submitstr + '}catch(e){}return false;" autocomplete="off"><div>' + str + '</div><div class="pns mtn"><button type="submit" id="' + ctrlid + '_submit" class="pn pnc"><strong>' + $L('submit') + '</strong></button><button type="button" onClick="hideMenu()" class="pn"><em>' + $L('cancel') + '</em></button></div></form></div>';
	}
	showMenu({'ctrlid':ctrlid,'evt':'click','duration':3,'cache':0,'drag':1});
}

function seditor_squarestrip(str) {
	str = str.replace('[', '%5B');
	str = str.replace(']', '%5D');
	return str;
}

function seditor_insertunit(key, text, textend, moveend, selappend) {
	if($(key + 'message')) {
		$(key + 'message').focus();
	}
	textend = isUndefined(textend) ? '' : textend;
	moveend = isUndefined(moveend) ? 0 : moveend;
	selappend = isUndefined(selappend) ? 1 : selappend;
	startlen = strlen(text);
	endlen = strlen(textend);
	
	// 检查是否有选中文本
	var hasSelection = false;
	if($(key + 'message') && !isUndefined($(key + 'message').selectionStart)) {
		hasSelection = $(key + 'message').selectionEnd > $(key + 'message').selectionStart;
	} else if($(key + 'message') && document.selection && document.selection.createRange) {
		var sel = document.selection.createRange();
		if(!sel.text.length && $(key + 'message').sel) {
			sel = $(key + 'message').sel;
			$(key + 'message').sel = null;
		}
		hasSelection = sel.text.length > 0;
	}
	
	// 如果没有选中文本且需要添加结束标签，则不执行插入操作
	if(selappend && textend != '' && !hasSelection) {
		return;
	}
	
	if($(key + 'message') && !isUndefined($(key + 'message').selectionStart)) {
		if(selappend) {
			var opn = $(key + 'message').selectionStart + 0;
			if(textend != '') {
				text = text + $(key + 'message').value.substring($(key + 'message').selectionStart, $(key + 'message').selectionEnd) + textend;
			}
			$(key + 'message').value = $(key + 'message').value.substr(0, $(key + 'message').selectionStart) + text + $(key + 'message').value.substr($(key + 'message').selectionEnd);
			if(!moveend) {
				$(key + 'message').selectionStart = opn + strlen(text) - endlen;
				$(key + 'message').selectionEnd = opn + strlen(text) - endlen;
			}
		} else {
			text = text + textend;
			$(key + 'message').value = $(key + 'message').value.substr(0, $(key + 'message').selectionStart) + text + $(key + 'message').value.substr($(key + 'message').selectionEnd);
		}
	} else if($(key + 'message') && document.selection && document.selection.createRange) {
		var sel = document.selection.createRange();
		if(!sel.text.length && $(key + 'message').sel) {
			sel = $(key + 'message').sel;
			$(key + 'message').sel = null;
		}
		if(selappend) {
			if(textend != '') {
				text = text + sel.text + textend;
			}
			sel.text = text.replace(/\r?\n/g, '\r\n');
			if(!moveend) {
				sel.moveStart('character', -endlen);
				sel.moveEnd('character', -endlen);
			}
			sel.select();
		} else {
			sel.text = text + textend;
		}
	} else if($(key + 'message')) {
			$(key + 'message').value += text;
		}
	hideMenu(2);
}

function seditor_ctlent(event, script) {
	if(event.ctrlKey && event.keyCode == 13 || event.altKey && event.keyCode == 83) {
		eval(script);
	}
}

function loadimgsize(imgurl, editor, p) {
	var editor = !editor ? editorid : editor;
	var s = new Object();
	var p = !p ? '_image' : p;
	s.img = new Image();
	s.img.src = imgurl;
	s.loadCheck = function () {
		if(s.img.complete) {
			$(editor + p + '_param_2').value = s.img.width ? s.img.width : '';
			$(editor + p + '_param_3').value = s.img.height ? s.img.height : '';
		} else {
			setTimeout(function () {s.loadCheck();}, 100);
		}
	};
	s.loadCheck();
}